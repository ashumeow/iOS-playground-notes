import UIKit

var name : String=""

func admit(person:String) {
    
}

func deny(person:String) {
    
}

func sendToOwner(person:String) {
    
}

func screenVIP(age: Int, onGuestList: Bool, knowsTheOwner: Bool) {
  if onGuestList && age >= 21 {
      admit(person: name)
  } else if knowsTheOwner {
      sendToOwner(person: name)
  } else {
      deny(person: name)
  }
}
